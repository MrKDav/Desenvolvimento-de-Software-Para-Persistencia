package lista_02;

import java.io.*;
import java.util.Scanner;

public class Questao01 {
    public static void main(String args[]) throws IOException{
        Scanner scan = new Scanner(System.in);
        System.out.print("Tamanho do bloco: ");
        int blockSize = scan.nextInt();

        InputStream is = new BufferedInputStream(new FileInputStream(args[0]), blockSize);
        OutputStream os = new BufferedOutputStream(new FileOutputStream(args[1]), blockSize);
        byte[] buffer = new byte[blockSize];

        long startTime = System.nanoTime();
        while (is.read(buffer) != -1) {
            try {
                os.write(buffer);
            } catch(IOException ex) {
                ex.printStackTrace();
            }
        }
        long endTime = System.nanoTime();

        double time = (double)(endTime - startTime)/1000000;

        System.out.println("A execução levou "+String.format("%.2f ms", time));
    }
}
